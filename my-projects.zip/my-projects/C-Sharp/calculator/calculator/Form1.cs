﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;

namespace calculator
{
    public partial class calculator : Form
    {
        string answer = "";
        public calculator()
        {
            InitializeComponent();
        }

        private void divButton_Click(object sender, EventArgs e)
        {
            answer = answer + "/";
            display.Text = answer;
        
    }

        private void zeroButton_Click(object sender, EventArgs e)
        {
            answer = answer + "0";
            display.Text = answer;
        }

        private void oneButton_Click(object sender, EventArgs e)
        {
            answer = answer + "1";
            display.Text = answer;
        }

        private void twoButton_Click(object sender, EventArgs e)
        {
            answer = answer + "2";
            display.Text = answer;
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            answer = answer + "+";
            display.Text = answer;
        }

        private void threeButton_Click(object sender, EventArgs e)
        {
            answer = answer + "3";
            display.Text = answer;
        }

        private void fourButton_Click(object sender, EventArgs e)
        {
            answer = answer + "4";
            display.Text = answer;
        }

        private void fiveButton_Click(object sender, EventArgs e)
        {
            answer = answer + "5";
            display.Text = answer;
        }

        private void subButton_Click(object sender, EventArgs e)
        {
            answer = answer + "-";
            display.Text = answer;
        }

        private void sixButton_Click(object sender, EventArgs e)
        {
            answer = answer + "6";
            display.Text = answer;
        }

        private void sevenButton_Click(object sender, EventArgs e)
        {
            answer = answer + "7";
            display.Text = answer;
        }

        private void eightButton_Click(object sender, EventArgs e)
        {
            answer = answer + "8";
            display.Text = answer;
        }

        private void multiButton_Click(object sender, EventArgs e)
        {
            answer = answer + "*";
            display.Text = answer;
        }

        private void nineButton_Click(object sender, EventArgs e)
        {
            answer = answer + "9";
            display.Text = answer;
        }

        private void equalButton_Click(object sender, EventArgs e)
        {
            
            DataTable dataTable = new DataTable();
            var result = dataTable.Compute(answer, "");
            display.Text = result.ToString();


        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            display.Text = "";
            answer = "";
        }
    }
}
