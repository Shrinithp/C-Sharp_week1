﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DigitalClock
{
    public partial class digitalClock : Form

    {
        Timer t = new Timer();
        public digitalClock()
        {
            InitializeComponent();
            
        }

        private void label1_Click(object sender, EventArgs e)
        {
            t.Interval = 1000;
            t.Tick += new EventHandler(this.t_tick);
            t.Start();

        }
        private void t_tick(object sender, EventArgs e)
        {
            int hour = DateTime.Now.Hour;   
            int minute = DateTime.Now.Minute;   
            int second = DateTime.Now.Second;

            string time = "";
            if(hour<10)
            {
                time += "0" + hour;

            }
            else
            {
                time += hour;
            }
            time += ":";
            if (minute < 10)
            {
                time += "0" + minute;

            }
            else
            {
                time += minute;
            }
            time += ":";
            if (second < 10)
            {
                time += "0" + second;

            }
            else
            {
                time += second;
            }
            time += ":";

            clockBox.Text = time;
        }
        
    }
}
