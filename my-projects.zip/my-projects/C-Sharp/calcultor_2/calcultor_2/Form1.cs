﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calcultor_2
{
    public partial class Form1 : Form
    {
        Double resultValue = 0;
        string operatorClicked = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            dispaly.Text += button.Text;

        }

        private void clear(object sender, EventArgs e)
        {
            dispaly.Text = "0";
            resultValue = 0;

        }

        private void calculate(object sender, EventArgs e)
        {
            switch (operatorClicked)
            {
                case "+":
                    dispaly.Text = (resultValue + Double.Parse(dispaly.Text)).ToString();
                    break;
                case "-":
                    dispaly.Text = (resultValue - Double.Parse(dispaly.Text)).ToString();
                    break;
                case "×":
                    dispaly.Text = (resultValue * Double.Parse(dispaly.Text)).ToString();
                    break;
                case "÷":
                    dispaly.Text = (resultValue / Double.Parse(dispaly.Text)).ToString();
                    break;
                default:
                    break;
            }
        }

        private void operatorClick(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            operatorClicked = button.Text;
            resultValue = Double.Parse(dispaly.Text);
        }
    }
}
