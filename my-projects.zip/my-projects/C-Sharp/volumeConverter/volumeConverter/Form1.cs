﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace volumeConverter
{
    public partial class converter : Form
    {
        public converter()
        {
            InitializeComponent();
            toLiters.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double gallons;
            double liters;
            const double ConversionRate = 3.785;
            gallons = Convert.ToInt32(gallonBox.Text);
            liters = ConversionRate * gallons;
            toLiters.Text = Convert.ToString(liters);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void literBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void clearAll_Click(object sender, EventArgs e)
        {
            gallonBox.Text = "";
            toLiters.Text = "";
        }

        private void converter_Load(object sender, EventArgs e)
        {

        }
    }
}
