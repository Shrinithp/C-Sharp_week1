﻿namespace volumeConverter
{
    partial class converter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(converter));
            this.ConvertButton = new System.Windows.Forms.Button();
            this.clearAll = new System.Windows.Forms.Button();
            this.Title = new System.Windows.Forms.Label();
            this.gallon = new System.Windows.Forms.Label();
            this.liters = new System.Windows.Forms.Label();
            this.gallonBox = new System.Windows.Forms.TextBox();
            this.toLiters = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // ConvertButton
            // 
            this.ConvertButton.BackColor = System.Drawing.Color.Cyan;
            this.ConvertButton.Location = new System.Drawing.Point(364, 222);
            this.ConvertButton.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.ConvertButton.Name = "ConvertButton";
            this.ConvertButton.Size = new System.Drawing.Size(94, 33);
            this.ConvertButton.TabIndex = 0;
            this.ConvertButton.Text = "Convert";
            this.ConvertButton.UseVisualStyleBackColor = false;
            this.ConvertButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // clearAll
            // 
            this.clearAll.BackColor = System.Drawing.Color.Red;
            this.clearAll.Location = new System.Drawing.Point(489, 222);
            this.clearAll.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.clearAll.Name = "clearAll";
            this.clearAll.Size = new System.Drawing.Size(98, 33);
            this.clearAll.TabIndex = 1;
            this.clearAll.Text = "Clear";
            this.clearAll.UseVisualStyleBackColor = false;
            this.clearAll.Click += new System.EventHandler(this.clearAll_Click);
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Title.Location = new System.Drawing.Point(276, 19);
            this.Title.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(333, 31);
            this.Title.TabIndex = 2;
            this.Title.Text = "Gallons to Liter Coverter";
            this.Title.Click += new System.EventHandler(this.label1_Click);
            // 
            // gallon
            // 
            this.gallon.AutoSize = true;
            this.gallon.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gallon.Location = new System.Drawing.Point(497, 118);
            this.gallon.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.gallon.Name = "gallon";
            this.gallon.Size = new System.Drawing.Size(68, 22);
            this.gallon.TabIndex = 3;
            this.gallon.Text = "Gallon";
            // 
            // liters
            // 
            this.liters.AutoSize = true;
            this.liters.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.liters.Location = new System.Drawing.Point(505, 164);
            this.liters.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.liters.Name = "liters";
            this.liters.Size = new System.Drawing.Size(50, 22);
            this.liters.TabIndex = 4;
            this.liters.Text = "Liter";
            // 
            // gallonBox
            // 
            this.gallonBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gallonBox.Location = new System.Drawing.Point(364, 118);
            this.gallonBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.gallonBox.Name = "gallonBox";
            this.gallonBox.Size = new System.Drawing.Size(116, 27);
            this.gallonBox.TabIndex = 5;
            this.gallonBox.TextChanged += new System.EventHandler(this.literBox_TextChanged);
            // 
            // toLiters
            // 
            this.toLiters.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toLiters.Location = new System.Drawing.Point(364, 161);
            this.toLiters.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.toLiters.Name = "toLiters";
            this.toLiters.Size = new System.Drawing.Size(116, 27);
            this.toLiters.TabIndex = 6;
            this.toLiters.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // converter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(933, 450);
            this.Controls.Add(this.toLiters);
            this.Controls.Add(this.gallonBox);
            this.Controls.Add(this.liters);
            this.Controls.Add(this.gallon);
            this.Controls.Add(this.Title);
            this.Controls.Add(this.clearAll);
            this.Controls.Add(this.ConvertButton);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "converter";
            this.Text = "Gallon to liter converter";
            this.Load += new System.EventHandler(this.converter_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ConvertButton;
        private System.Windows.Forms.Button clearAll;
        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.Label gallon;
        private System.Windows.Forms.Label liters;
        private System.Windows.Forms.TextBox gallonBox;
        private System.Windows.Forms.TextBox toLiters;
    }
}

